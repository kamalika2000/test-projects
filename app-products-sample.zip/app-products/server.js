"use strict";
const servernew = require('server');
var express = require('express');
var app = express();
const { get, post } = servernew.router;
exports.__esModule = true;
var http_1 = require("http");
var hostname = '127.0.0.1';
var port = 3000;
var server = http_1.createServer(function (req, res) {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.end('Hello, World!');
});
server.listen(port, hostname, function () {
    console.log("Server running at http://".concat(hostname, ":").concat(port, "/"));
});

app.get('/users', function(req, res) {
    res.send({
          customerName : 'abc',
          purchase : 200,
          deliverDate : new Date()
      });
  });
