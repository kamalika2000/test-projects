import { Injectable } from '@angular/core';
import { WebApiService } from './web-api.service';
import { BehaviorSubject, Observable, filter, map } from 'rxjs';

export interface products{
  id: string;
  title: string;
  type: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  public entities$: Observable<any[]>;
  private entitySource: BehaviorSubject<any[]>;
  public prodDet$: Observable<products>;
  private prodDetSource: BehaviorSubject<products>;

  constructor(private webApi: WebApiService) {
    this.entitySource = new BehaviorSubject([]); // Default value []
    this.entities$ = this.entitySource.asObservable();
    this.prodDetSource = new BehaviorSubject(({} as any) as products);
    this.prodDet$ = this.prodDetSource.asObservable();
   }
  public getProducts(){
    return this.webApi.get('assets/json/products.json').subscribe(data => {
      this.entitySource.next(data);
    });
  }
  public getProductDetails(pid: string): Observable<products[]>{
    return this.webApi.get('assets/json/products.json').pipe(map(data => {
      const res = data.filter(element => {  
        return (element.id === pid);
      });
      return res;
    }));
  }
  public getSimilarProducts(text: string): Observable<products[]>{
    return this.webApi.get('assets/json/similar-products.json').pipe(map(data => {
      const res = data.filter(element => {  
        return (element.type.includes(text));
      });
      return res;
    }));
  }
  public updateProducts(payload: products): Observable<products>{
    return this.webApi.post('assets/json/similar-products.json', payload).pipe(map(data => payload)); //sample post json
  }
}
