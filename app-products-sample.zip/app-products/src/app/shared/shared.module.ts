import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { SharedService } from './shared.service';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TableModule,
    InputTextModule,
    AutoCompleteModule,
    DropdownModule,
    ReactiveFormsModule,
    InputTextareaModule
  ],
  exports: [
    TableModule,
    InputTextModule,
    AutoCompleteModule,
    DropdownModule,
    ReactiveFormsModule,
    InputTextareaModule
  ],
  providers: [
    SharedService
  ]
})
export class SharedModule { }
