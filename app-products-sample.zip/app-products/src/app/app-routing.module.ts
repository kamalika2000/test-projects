import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  {path: '', component: AppComponent, pathMatch:'full', redirectTo: ''},
  {path: 'home', loadChildren: () => import('../app/product-home/product-home.module').then(m => m.ProductHomeModule)},
  {path: 'product-list', loadChildren: () => import('../app/product-list/product-list.module').then(m => m.ProductListModule)},
  {path: 'product-details/:id', loadChildren: () => import('../app/product-details/product-details.module').then(m => m.ProductDetailsModule)},
  /* {path: 'login', component: LoginComponent},
  {path: 'home', component: DashboardComponent, canActivate:[AuthGuard]}, */
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
