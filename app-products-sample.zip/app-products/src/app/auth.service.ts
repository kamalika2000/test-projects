import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public userDetails: any;
  constructor(private http: HttpClient) { }
  isLoggedIn(username, passwd): Observable<boolean> {
    let credentials: any = {};
    credentials.username = username;
    credentials.pwd = passwd;
    return this.http.get('../../assets/json/submit.json')
      .pipe(map(user => {
        user = credentials;
        if (user){
          this.userDetails = user;
          return true;
        }
        
      }), catchError(error => {
        throw error;
      })
      )

  }
}
