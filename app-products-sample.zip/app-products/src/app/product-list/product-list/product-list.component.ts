import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent {
  cols: any = [];
  products: any;
  productsVal$: Observable<any>;
  constructor(private sharedService: SharedService){

  }
  ngOnInit(){
    this.cols = [
      {header: 'Name', field: 'title', width: '20%'},
      {header: 'Category', field: 'type', width: '20%'},
      {header: 'Description', field: 'description', width: '60%'}
    ]
    
    this.sharedService.getProducts();
    this.productsVal$ = this.sharedService.entities$;
  }
}
