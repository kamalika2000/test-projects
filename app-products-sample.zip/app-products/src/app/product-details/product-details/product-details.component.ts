import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { SelectItem } from 'primeng/api';
import { BehaviorSubject, Observable, debounceTime, switchMap } from 'rxjs';
import { SharedService, products } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent {
  routeDetails: any;
  productForm: any;
  productsVal$: Observable<object>;
  selectedItem: any[];
  options: any[];
  $filtered = new BehaviorSubject([]);
  category: SelectItem[];
  constructor(private sharedService: SharedService, private route: ActivatedRoute, private router: Router){
    this.productForm = new FormGroup({
      title: new FormControl('',Validators.required),
      type: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
      similarItems: new FormControl('')
    })
  }
  ngOnInit(){
    this.category = [
      {
        "label": "fruit",
        "value": "fruit"
      },
      {
        "label": "bakery",
        "value": "bakery"
      },
      {
        "label": "vegetable",
        "value": "vegetable"
      },
      {
        "label": "dairy",
        "value": "dairy"
      }
  ]
    this.routeDetails = this.route.snapshot.params;
    /* this.productForm.get('similarItems').valueChanges.pipe(
      debounceTime(500),
      switchMap((text) => {
        return this.fetchResult(text)
      })
    ).subscribe(data => {
      console.log(data);
    }) */
   this.sharedService.getProductDetails(this.routeDetails.id).subscribe(data => {
    if(data.length > 0){
      this.productForm.patchValue({
        title: data[0]?.title,
        type: data[0]?.type,
        description: data[0]?.description,
        similarItems: ''
      });
    } else{
      this.router.navigate(['product-list']);
    }
      
    })
    
    
  }
  filterMethod(event) {
		this.sharedService.getSimilarProducts(event.query).subscribe(res => {
      this.$filtered.next([...res]);
			//this.options = [...res];
		});
	}
  searchText(event){
    this.productForm.get('similarItems').valueChanges.pipe(
      debounceTime(500),
      switchMap((text) => {
        return this.fetchResult(text)
      })
    ).subscribe(data => {
      console.log(data);
    })
  }
  fetchResult(queryParams?: any): Observable<any> {
    
    return this.sharedService.getSimilarProducts(queryParams);
  }
  onSubmit(){
    let payload: products = ({} as any) as products;
    if(this.productForm.valid){
      payload.title = this.productForm.get('title').value;
      payload.description = this.productForm.get('description').value;
      payload.type = this.productForm.get('type').value;
      payload.id = this.routeDetails.id;
      this.sharedService.updateProducts(payload).subscribe(data => {
        this.productForm.patchValue({
          title: data[0]?.title,
          type: data[0]?.type,
          description: data[0]?.description,
          similarItems: ''
        });
      })
    }
  }
}
