import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormControlName, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public loginForm = new FormGroup({
    name: new FormControl('',Validators.required),
    password: new FormControl('', Validators.required)
  }) ;;

  constructor(private authService: AuthService,private router: Router, private route: ActivatedRoute) {
   }

  ngOnInit(): void {
  }
  onSubmit(){
    this.authService.isLoggedIn(this.loginForm.get('name').value, this.loginForm.get('password').value).subscribe(data => {
      //let returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
      this.router.navigate(['home'], {queryParams:{order: 'test', id: 1}});
      console.log(data);
    })
  }

}
